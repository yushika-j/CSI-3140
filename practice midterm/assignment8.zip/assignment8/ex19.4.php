<!-- Yushika Jhundoo - 300269830
Nidhi Thakkar - 300202450 -->


$pattern = '^A[A-Za-z0-9]{3}[Bb]+\d{2}$/';

<!-- 
A matches the uppercase letter A.
[A-Za-z0-9]{3} matches any three alphanumeric characters.
[Bb]+ matches one or more occurrences of the uppercase or lowercase letter B.
\d{2} matches exactly two digits. -->

// ********************************
//Yushika Jhundoo - 300269830
//Nidhi Pareshkumar Thakkar - 300202450
//************************************* 

//The following is the corrected code:
if ( age >= 65 ) {
    document.writeln( "Age greater than or equal to 65" );
} else {
    document.writeln( "Age is less than 65" );
}

//b)
var x = 1, total = 0;
while (x <= 10) {
    total += x;
    ++x;
}

//c)
var x = 1;
var total = 0;
while ( x <= 100 ){
    total += x;
    ++x;
}

//d)
var y = 5;
while (y> 0 ){
    document.writeln( y );
    ++y
}
